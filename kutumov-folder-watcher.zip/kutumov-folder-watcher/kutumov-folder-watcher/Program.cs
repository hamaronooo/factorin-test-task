﻿using System;
using System.Collections.Generic;
using System.Threading;
using kutumov_folder_watcher.Services.FileHandlersManagers;
using kutumov_folder_watcher.Services.FolderWatchers;
using kutumov_folder_watcher.Services.Loggers;
using kutumov_folder_watcher.Services.ResultsWriter;
using Microsoft.Extensions.Configuration;

namespace kutumov_folder_watcher
{
    /*
     *  IConfigurationRoot - конфигурация из файла appsettings.json
     *  ILogger - записывает логи, в данном случае в консоль
     *  IResultsWriter - записывает рузельтат обработки файлов, в данном случае в .txt
     *  IFileHandler - обработчик файлов
     *  IFileHandlersManager - резолвер IFileHandler
     *  ---------------
     *  Watcher реализован с помощью FileSystemWatcher в IFolderWatcher
     */
    internal class Program
    {
        private static IConfigurationRoot LoadConfiguration() =>  new Init().LoadConfiguration();

        private static void Main(string[] args)
        {
            // load config && create dep's for inject
            ILogger logger = new ConsoleLogger();
            IConfigurationRoot config = LoadConfiguration();
            IResultsWriter resultsWriter = new FileResultsWriter(logger, config);
            IFileHandlersManager fileHandlersManager = new DefaultFileHandlersManager(logger, resultsWriter);

            Console.Title = config["AppName"] ?? "Console";
            logger.LogWarning("Пожалуйста замените Пути в файле appsettings.json на комфортные Вам.");

            // get directories for watch from config
            var directoriesToWatch =
                config.GetSection("Watcher:Directories").Get<IEnumerable<string>>();

            // init watchers
            CancellationTokenSource cancelTokenSource = new();
            foreach (var target in directoriesToWatch)
                new BaseFolderWatcher(logger, fileHandlersManager)?
                    .WatchAsync(target, cancelTokenSource.Token);
            
            Console.ReadKey();
        }
    }
}