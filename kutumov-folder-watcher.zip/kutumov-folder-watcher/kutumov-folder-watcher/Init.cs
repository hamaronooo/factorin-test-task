﻿using Microsoft.Extensions.Configuration;

namespace kutumov_folder_watcher
{
    internal class Init
    {
        public IConfigurationRoot LoadConfiguration()
        {
            var builder = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json", true, true)
                .AddEnvironmentVariables();

            return builder.Build();
        }
    }
}