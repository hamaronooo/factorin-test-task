﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using kutumov_folder_watcher.Services.FileHandlersManagers;
using kutumov_folder_watcher.Services.Loggers;

namespace kutumov_folder_watcher.Services.FolderWatchers
{
    internal class BaseFolderWatcher : IFolderWatcher
    {
        private readonly IFileHandlersManager _fileHandlersManager;
        private readonly ILogger _logger;

        public BaseFolderWatcher(ILogger logger, IFileHandlersManager fileHandlersManager)
        {
            _logger = logger;
            _fileHandlersManager = fileHandlersManager;
        }

        /// <summary>
        /// Start watch for directory
        /// </summary>
        /// <param name="folderPath">Directory full path</param>
        /// <param name="cancel">Cancellation</param>
        /// <returns></returns>
        /// <exception cref="DirectoryNotFoundException"></exception>
        public async Task WatchAsync(string folderPath, CancellationToken cancel)
        {
            DirectoryInfo dirInfo = new(folderPath);

            _logger.LogWarning($"Start watching for folder: {folderPath}");

            if (dirInfo.Exists == false)
                throw new DirectoryNotFoundException();

            var watcher = new FileSystemWatcher(folderPath);
            watcher.Created += OnCreated;
            watcher.EnableRaisingEvents = true;
            
            await Task.Delay(1);
        }

        private void OnCreated(object sender, FileSystemEventArgs e)
        {
            _logger.LogInfo("File created: " + e.Name + Environment.NewLine + "At directory " + e.FullPath);

            var fileHandler = _fileHandlersManager.Manage(new FileInfo(e.FullPath));
            _logger.LogInfo($"FileHandlersManager has create handler of type: {fileHandler.GetType().Name}");
            fileHandler.HandleAsync(e.FullPath);
        }
    }
}