﻿using System.Threading;
using System.Threading.Tasks;

namespace kutumov_folder_watcher.Services.FolderWatchers
{
    internal interface IFolderWatcher
    {
        Task WatchAsync(string folderPath, CancellationToken cancel);
    }
}