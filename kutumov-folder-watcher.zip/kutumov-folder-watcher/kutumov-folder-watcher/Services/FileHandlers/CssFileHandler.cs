﻿using System.IO;
using System.Threading.Tasks;
using kutumov_folder_watcher.Models;
using kutumov_folder_watcher.Services.Loggers;
using kutumov_folder_watcher.Services.ResultsWriter;

namespace kutumov_folder_watcher.Services.FileHandlers
{
    internal class CssFileHandler : BaseFileHandler
    {
        public CssFileHandler(ILogger logger, IResultsWriter resultsWriter) : base(logger, resultsWriter) { }

        public override async Task HandleAsync(string fileName)
        {
            var fInfo = new FileInfo(fileName);

            if (fInfo.Exists == false)
            {
                _logger.LogError($"File {fileName} wasn't found");
                throw new FileNotFoundException(fileName);
            }

            long openBrackets = default;
            long closeBrackets = default;
            var content = await File.ReadAllLinesAsync(fInfo.FullName);

            // Пересчет количества знаков препинания
            for (var index = 0; index < content.Length; index++)
            for (var i = 0; i < content[index].Length; i++)
                if (content[index][i] == '{')
                    openBrackets++;
                else if (content[index][i] == '}')
                    closeBrackets++;

            _logger.LogInfo($"Is brackets match: {openBrackets == closeBrackets}");

            await base.WriteResult(new ResultModel(fileName,
                "Количество закрывающих скобок совпадает с количеством открывающих?",
                (openBrackets == closeBrackets).ToString())
            ).ConfigureAwait(false);
        }
    }
}