﻿using System.Threading.Tasks;

namespace kutumov_folder_watcher.Services.FileHandlers
{
    internal interface IFileHandler
    {
        Task HandleAsync(string fileName);
    }
}