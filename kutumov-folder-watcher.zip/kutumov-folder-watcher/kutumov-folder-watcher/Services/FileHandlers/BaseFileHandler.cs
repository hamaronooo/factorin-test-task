﻿using System.IO;
using System.Linq;
using System.Threading.Tasks;
using kutumov_folder_watcher.Models;
using kutumov_folder_watcher.Services.Loggers;
using kutumov_folder_watcher.Services.ResultsWriter;

namespace kutumov_folder_watcher.Services.FileHandlers
{
    internal class BaseFileHandler : IFileHandler
    {
        private static readonly char[] _punctuationMarks =
            { '.', ',', ';', '!', '?', '-', ':', '\'', '\"', '(', ')', '{', '}', ']', '[' };

        protected readonly ILogger _logger;
        protected readonly IResultsWriter _resultsWriter;

        public BaseFileHandler(ILogger logger, IResultsWriter resultsWriter)
        {
            _logger = logger;
            _resultsWriter = resultsWriter;
        }

        /// <summary>
        ///     Пересчет количества знаков препинания <br />
        ///     Действие по умолчанию
        /// </summary>
        /// <param name="fileName">Полное имя файла</param>
        /// <returns></returns>
        /// <exception cref="FileNotFoundException"></exception>
        public virtual async Task HandleAsync(string fileName)
        {
            var fInfo = new FileInfo(fileName);

            if (fInfo.Exists == false)
            {
                _logger.LogError($"File {fileName} wasn't found");
                throw new FileNotFoundException(fileName);
            }

            long result = default;
            var content = await File.ReadAllLinesAsync(fInfo.FullName);

            // Пересчет количества знаков препинания
            for (var index = 0; index < content.Length; index++)
            for (var i = 0; i < content[index].Length; i++)
                if (_punctuationMarks.Contains(content[index][i]))
                    result++;

            _logger.LogInfo("File just handled in base handler");
            await WriteResult(new ResultModel(
                fInfo.FullName,
                "Рассчет количества знаков препинания",
                result.ToString())
            ).ConfigureAwait(false);
        }

        protected virtual async Task WriteResult(ResultModel result)
        {
            await _resultsWriter.WriteAsync(result);
        }
    }
}