﻿using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using kutumov_folder_watcher.Models;
using kutumov_folder_watcher.Services.Loggers;
using kutumov_folder_watcher.Services.ResultsWriter;

namespace kutumov_folder_watcher.Services.FileHandlers
{
    internal class HtmlFileHandler : BaseFileHandler
    {
        public HtmlFileHandler(ILogger logger, IResultsWriter resultsWriter) : base(logger, resultsWriter) { }

        public override async Task HandleAsync(string fileName)
        {
            var fInfo = new FileInfo(fileName);

            if (fInfo.Exists == false)
            {
                _logger.LogError($"File {fileName} wasn't found");
                throw new FileNotFoundException(fileName);
            }

            var content = await File.ReadAllTextAsync(fInfo.FullName);
            var cleared = Regex.Replace(content.ToLower(), "(\n|\r|\t|\a)", string.Empty);

            // Пересчет количества вхождения div тэгов
            var count = Regex.Matches(cleared, @"(\<)div(\s|\*?)>?").Count;
            _logger.LogInfo($"Div tags count: {count}");
            await base.WriteResult(new ResultModel(fileName,
                "Количество тэгов div",
                $"{count} шт")
            ).ConfigureAwait(false);
        }
    }
}