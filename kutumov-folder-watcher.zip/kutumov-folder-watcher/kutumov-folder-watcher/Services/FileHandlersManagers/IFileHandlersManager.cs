﻿using System.IO;
using kutumov_folder_watcher.Services.FileHandlers;

namespace kutumov_folder_watcher.Services.FileHandlersManagers
{
    internal interface IFileHandlersManager
    {
        IFileHandler Manage(string fileExtension);
        IFileHandler Manage(FileInfo fileInfo);
    }
}