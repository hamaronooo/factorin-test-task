﻿using System;
using System.IO;
using System.Linq;
using kutumov_folder_watcher.Services.FileHandlers;
using kutumov_folder_watcher.Services.Loggers;
using kutumov_folder_watcher.Services.ResultsWriter;

namespace kutumov_folder_watcher.Services.FileHandlersManagers
{
    internal class DefaultFileHandlersManager : IFileHandlersManager
    {
        private readonly ILogger _logger;
        private readonly IResultsWriter _resultsWriter;

        public DefaultFileHandlersManager(ILogger logger, IResultsWriter resultsWriter)
        {
            _logger = logger;
            _resultsWriter = resultsWriter;
        }

        public IFileHandler Manage(string fileExtension)
        {
            if (fileExtension.ToCharArray().Count(x => x == '.') > 1)
                throw new Exception("Wrong extension name. Too many dots.");
            
            if (fileExtension.Contains('.') == false)
                fileExtension = "." + fileExtension;

            return fileExtension.ToLower() switch
            {
                ".css" => new CssFileHandler(_logger, _resultsWriter),
                ".html" => new HtmlFileHandler(_logger, _resultsWriter),
                _ => new BaseFileHandler(_logger, _resultsWriter)
            };
        }

        public IFileHandler Manage(FileInfo fileInfo)
        {
            return Manage(fileInfo.Extension);
        }
    }
}