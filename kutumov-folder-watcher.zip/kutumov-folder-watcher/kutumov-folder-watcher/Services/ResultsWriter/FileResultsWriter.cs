﻿using System;
using System.IO;
using System.Threading.Tasks;
using kutumov_folder_watcher.Models;
using kutumov_folder_watcher.Services.Loggers;
using Microsoft.Extensions.Configuration;

namespace kutumov_folder_watcher.Services.ResultsWriter
{
    internal class FileResultsWriter : IResultsWriter
    {
        private readonly IConfigurationRoot _config;
        private readonly ILogger _logger;

        public FileResultsWriter(ILogger logger, IConfigurationRoot config)
        {
            _logger = logger;
            _config = config;
        }

        public async Task WriteAsync(ResultModel result)
        {
            var resultFolder = _config["ResultDirectory"];

            if (Directory.Exists(resultFolder) == false)
            {
                _logger.LogError("Results directory wasn't found");
                throw new DirectoryNotFoundException(resultFolder + " was not found");
            }

            var fileName = $"{resultFolder}\\{DateTime.Now:dd_MM_yyyy}_results.txt";

            if (File.Exists(fileName) == false)
                await File.Create(fileName).DisposeAsync();

            try
            {
                await File.AppendAllTextAsync(fileName, GetResultMessage(result));
            }
            catch (FileLoadException e)
            {
                _logger.LogError(e);
                throw e;
            }
        }

        private string GetResultMessage(ResultModel result)
        {
            return $"{result.FileName}-{result.OperationName}-{result.Result}{Environment.NewLine}";
        }
    }
}