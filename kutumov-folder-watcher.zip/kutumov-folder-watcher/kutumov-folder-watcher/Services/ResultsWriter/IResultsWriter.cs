﻿using System.Threading.Tasks;
using kutumov_folder_watcher.Models;

namespace kutumov_folder_watcher.Services.ResultsWriter
{
    internal interface IResultsWriter
    {
        Task WriteAsync(ResultModel result);
    }
}