﻿using System;

namespace kutumov_folder_watcher.Services.Loggers
{
    internal interface ILogger
    {
        void Log(string message);
        void LogInfo(string message);
        void LogWarning(string warning);
        void LogError(Exception ex);
        void LogError(string error);
    }
}