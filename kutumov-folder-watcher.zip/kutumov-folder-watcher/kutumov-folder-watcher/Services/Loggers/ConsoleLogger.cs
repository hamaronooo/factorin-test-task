﻿using System;

namespace kutumov_folder_watcher.Services.Loggers
{
    internal class ConsoleLogger : ILogger
    {
        public void Log(string message)
        {
            Console.ResetColor();
            Console.WriteLine($"[{DateTime.Now:dd.MM.yy HH:mm:ss}]{Environment.NewLine}{message}{Environment.NewLine}");
        }

        public void LogInfo(string message)
        {
            Console.ResetColor();
            Console.WriteLine($"[{DateTime.Now:dd.MM.yy HH:mm:ss}]{Environment.NewLine}{message}{Environment.NewLine}",
                Console.ForegroundColor = ConsoleColor.Cyan);
        }

        public void LogWarning(string warning)
        {
            Console.ResetColor();
            Console.WriteLine($"[{DateTime.Now:dd.MM.yy HH:mm:ss}]{Environment.NewLine}{warning}{Environment.NewLine}",
                Console.ForegroundColor = ConsoleColor.Yellow);
        }

        public void LogError(Exception ex)
        {
            Console.ResetColor();
            Console.WriteLine(
                $"[{DateTime.Now:dd.MM.yy HH:mm:ss}]{Environment.NewLine}{ex.Message}{Environment.NewLine}",
                Console.ForegroundColor = ConsoleColor.Red);
        }

        public void LogError(string error)
        {
            Console.ResetColor();
            Console.WriteLine($"[{DateTime.Now:dd.MM.yy HH:mm:ss}]{Environment.NewLine}{error}{Environment.NewLine}",
                Console.ForegroundColor = ConsoleColor.Red);
        }
    }
}