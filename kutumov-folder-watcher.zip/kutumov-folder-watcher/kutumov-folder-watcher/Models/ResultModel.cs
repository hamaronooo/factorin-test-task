﻿namespace kutumov_folder_watcher.Models
{
    internal record ResultModel(string FileName, string OperationName, string Result);
}